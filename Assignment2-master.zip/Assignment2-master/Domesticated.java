package assignment2;

public interface Domesticated {
	void walk();
	void greetHuman();
}
