package assignment2;

public class ProductTest {

	public static void main(String[] args) {
		Product product = new Product("potato", "vegetable", 5.50, 10);
		System.out.println(product.toString()); 

	}

}
